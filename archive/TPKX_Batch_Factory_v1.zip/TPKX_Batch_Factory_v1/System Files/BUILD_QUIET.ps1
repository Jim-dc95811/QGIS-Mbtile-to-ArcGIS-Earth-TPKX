Add-Type -AssemblyName PresentationFramework
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $PSScriptRoot
$Project = Join-Path $PSScriptRoot "ArcGIS_TPKX_Factory.csproj"
$DotNet = Join-Path $env:ProgramFiles "dotnet\dotnet.exe"
$SdkTarget = "C:\Program Files\ArcGIS\Pro\bin\Esri.ProApp.SDK.Desktop.targets"
$CoreDll = "C:\Program Files\ArcGIS\Pro\bin\Extensions\Core\ArcGIS.Desktop.Core.dll"
$Log = Join-Path $PSScriptRoot "BUILD_LOG.txt"   # 2026-11-06: log stays inside System Files

# Remove retired single-screen files and stale build output before compiling.
@("FactoryWindow.xaml", "FactoryWindow.xaml.cs") | ForEach-Object {
    $stale = Join-Path $PSScriptRoot $_
    if (Test-Path $stale) { Remove-Item $stale -Force }
}
@("bin", "obj") | ForEach-Object {
    $stale = Join-Path $PSScriptRoot $_
    if (Test-Path $stale) { Remove-Item $stale -Recurse -Force }
}

function Popup([string]$message, [string]$title, [System.Windows.MessageBoxImage]$icon) {
    [System.Windows.MessageBox]::Show(
        $message,
        $title,
        [System.Windows.MessageBoxButton]::OK,
        $icon
    ) | Out-Null
}

try {
    "ArcGIS TPKX Factory 9 - quiet build" | Set-Content -Path $Log -Encoding UTF8
    ("Started: " + (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")) | Add-Content $Log

    if (-not (Test-Path $DotNet)) { throw ".NET build tools were not found." }
    if (-not (Test-Path $SdkTarget)) { throw "ArcGIS Pro SDK build target was not found." }
    if (-not (Test-Path $CoreDll)) { throw "ArcGIS.Desktop.Core.dll was not found." }

    $window = New-Object System.Windows.Window
    $window.Title = "ArcGIS TPKX Factory"
    $window.Width = 430
    $window.Height = 165
    $window.WindowStartupLocation = "CenterScreen"
    $window.ResizeMode = "NoResize"
    $window.Topmost = $true

    $panel = New-Object System.Windows.Controls.StackPanel
    $panel.Margin = "22"

    $title = New-Object System.Windows.Controls.TextBlock
    $title.Text = "Building ArcGIS TPKX Factory..."
    $title.FontSize = 18
    $title.FontWeight = "SemiBold"
    $panel.Children.Add($title) | Out-Null

    $sub = New-Object System.Windows.Controls.TextBlock
    $sub.Text = "This normally takes only a few seconds."
    $sub.Margin = "0,8,0,14"
    $panel.Children.Add($sub) | Out-Null

    $bar = New-Object System.Windows.Controls.ProgressBar
    $bar.Height = 10
    $bar.IsIndeterminate = $true
    $panel.Children.Add($bar) | Out-Null

    $window.Content = $panel
    $window.Show()

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $DotNet
    $psi.Arguments = "build `"$Project`" -c Debug"
    $psi.WorkingDirectory = $PSScriptRoot
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    [void]$proc.Start()

    $stdoutTask = $proc.StandardOutput.ReadToEndAsync()
    $stderrTask = $proc.StandardError.ReadToEndAsync()

    while (-not $proc.HasExited) {
        [System.Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke(
            [Action]{},
            [System.Windows.Threading.DispatcherPriority]::Background
        )
        Start-Sleep -Milliseconds 100
    }

    $stdoutTask.Result | Add-Content $Log
    $stderrTask.Result | Add-Content $Log

    $window.Close()

    if ($proc.ExitCode -ne 0) {
        Popup "The Factory did not build.`n`nNothing was installed.`n`nTechnical log:`n$Log" `
              "ArcGIS TPKX Factory - Build Failed" `
              ([System.Windows.MessageBoxImage]::Error)
        exit 1
    }

    $addin = Get-ChildItem -Path (Join-Path $PSScriptRoot "bin") -Filter *.esriAddInX -Recurse |
             Select-Object -First 1

    if ($null -eq $addin) {
        Popup "The code compiled, but the ArcGIS add-in package could not be located.`n`nLog:`n$Log" `
              "ArcGIS TPKX Factory" `
              ([System.Windows.MessageBoxImage]::Warning)
        exit 2
    }

    Popup "Build complete.`n`nArcGIS will now open its Add-In Installation Utility.`nClick Install Add-In, then restart ArcGIS Pro once." `
          "ArcGIS TPKX Factory - Ready to Install" `
          ([System.Windows.MessageBoxImage]::Information)

    Start-Process $addin.FullName
    exit 0
}
catch {
    try { if ($window) { $window.Close() } } catch {}
    ($_ | Out-String) | Add-Content $Log
    Popup ("The Factory could not be prepared.`n`n" + $_.Exception.Message + "`n`nLog:`n" + $Log) `
          "ArcGIS TPKX Factory" `
          ([System.Windows.MessageBoxImage]::Error)
    exit 3
}
