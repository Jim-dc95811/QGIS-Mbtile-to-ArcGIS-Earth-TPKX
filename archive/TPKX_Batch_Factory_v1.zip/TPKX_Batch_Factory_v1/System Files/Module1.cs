using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Contracts;

namespace ArcGIS_TPKX_Factory
{
    internal class Module1 : Module
    {
        private static Module1? _this;

        public static Module1 Current =>
            _this ??= (Module1)FrameworkApplication.FindModule("ArcGIS_TPKX_Factory_Module");

        protected override bool CanUnload() => true;
    }
}
