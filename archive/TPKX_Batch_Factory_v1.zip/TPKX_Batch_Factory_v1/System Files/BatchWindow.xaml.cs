using ArcGIS.Core.Geometry;
using ArcGIS.Core.CIM;
using ArcGIS.Desktop.Core;
using ArcGIS.Desktop.Framework.Controls;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;
using ArcGIS.Desktop.Mapping.Offline;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ArcGIS_TPKX_Factory
{
    public partial class BatchWindow : ProWindow
    {
        private static BatchWindow _instance;
        private bool _cancelRequested;
        private readonly List<TextBox> _extentBoxes;

        private const string ImageryUrl =
            "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer";

        private const string TransportationUrl =
            "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer";

        private const string ImageryLayerName = "World Imagery";
        private const string TransportationLayerName = "Reference/World_Transportation";

        private static readonly Dictionary<int, double> ZoomScales = new()
        {
            { 0, 591657527.591555 },
            { 1, 295828763.795777 },
            { 2, 147914381.897889 },
            { 3, 73957190.948944 },
            { 4, 36978595.474472 },
            { 5, 18489297.737236 },
            { 6, 9244648.868618 },
            { 7, 4622324.434309 },
            { 8, 2311162.217155 },
            { 9, 1155581.108577 },
            { 10, 577790.554289 },
            { 11, 288895.277144 },
            { 12, 144447.638572 },
            { 13, 72223.819286 },
            { 14, 36111.909643 },
            { 15, 18055.954822 },
            { 16, 9027.977411 },
            { 17, 4513.988705 },
            { 18, 2256.994353 },
            { 19, 1128.497176 },
            { 20, 564.248588 }
        };

        private static readonly Regex ExtentRegex = new(
            @"^\s*(?:(?<label>[^\s,]+)\s+)?" +
            @"(?<xmin>-?\d+(?:\.\d+)?)\s*,\s*" +
            @"(?<xmax>-?\d+(?:\.\d+)?)\s*,\s*" +
            @"(?<ymin>-?\d+(?:\.\d+)?)\s*,\s*" +
            @"(?<ymax>-?\d+(?:\.\d+)?)" +
            @"(?:\s*\[EPSG:\s*3857\])?\s*$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public BatchWindow()
        {
            InitializeComponent();
            _extentBoxes = new List<TextBox>
            {
                Extent1, Extent2, Extent3, Extent4, Extent5,
                Extent6, Extent7, Extent8, Extent9, Extent10
            };

            Closed += (_, __) =>
            {
                if (ReferenceEquals(_instance, this))
                    _instance = null;
            };
        }

        public static void ShowFactory()
        {
            if (_instance == null)
            {
                _instance = new BatchWindow();
                _instance.Show();
            }
            else
            {
                if (_instance.WindowState == WindowState.Minimized)
                    _instance.WindowState = WindowState.Normal;

                _instance.Activate();
            }
        }

        private void PasteMultipleButton_Click(object sender, RoutedEventArgs e)
        {
            if (!Clipboard.ContainsText())
            {
                SetStatus("Clipboard does not contain text.");
                return;
            }

            var lines = Clipboard.GetText()
                .Split(new[] { "\r\n", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Take(10)
                .ToList();

            for (int i = 0; i < _extentBoxes.Count; i++)
                _extentBoxes[i].Text = i < lines.Count ? lines[i] : "";

            SetStatus($"Loaded {lines.Count} extent line(s) from the clipboard.");
        }

        private void ClearRowsButton_Click(object sender, RoutedEventArgs e)
        {
            if (BuildBatchButton.IsEnabled == false)
                return;

            foreach (var box in _extentBoxes)
                box.Clear();

            SetStatus("Rows cleared.");
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog
            {
                Title = "Choose batch destination folder",
                Multiselect = false
            };

            if (Directory.Exists(DestinationTextBox.Text))
                dialog.InitialDirectory = DestinationTextBox.Text;

            if (dialog.ShowDialog() == true)
                DestinationTextBox.Text = dialog.FolderName;
        }

        private void CancelBatchButton_Click(object sender, RoutedEventArgs e)
        {
            _cancelRequested = true;
            CancelBatchButton.IsEnabled = false;

            SetStatus(
                "CANCEL REQUESTED.\n\n" +
                "The current ArcGIS export will be allowed to finish safely. " +
                "No remaining jobs will be started.");
        }

        private async void BuildBatchButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryReadBatch(out var request, out var error))
            {
                SetStatus("BATCH INPUT ERROR\n\n" + error);
                return;
            }

            _cancelRequested = false;
            SetBusy(true);
            OverallProgressBar.Maximum = request.Jobs.Count;
            OverallProgressBar.Value = 0;

            string logPath = Path.Combine(
                request.Destination,
                $"ArcGIS_TPKX_Batch_{DateTime.Now:yyyyMMdd_HHmmss}.txt");

            try
            {
                Directory.CreateDirectory(request.Destination);

                SetStatus(
                    $"PREFLIGHTING {request.Jobs.Count} JOB(S)...\n" +
                    "No production will start until every requested extent is validated.");

                // Preflight is done in a private map that is never opened in ArcGIS Pro.
                // It contains only the selected live source(s), so the user's active map,
                // previously exported TPKX files, basemaps, and other layers cannot take
                // part in the batch.
                Map preflightMap = null;
                string preflightMapName = null;
                var preflightFailures = new List<string>();

                try
                {
                    var created = await QueuedTask.Run(() => CreatePrivateBatchMap(request.Product, "PREFLIGHT"));
                    preflightMap = created.Map;
                    preflightMapName = created.Name;

                    foreach (var job in request.Jobs)
                    {
                        var preflight = await PreflightJob(preflightMap, job, request.Zoom);
                        job.ArcGISScale = preflight.ArcGISScale;

                        if (!preflight.Allowed)
                        {
                            preflightFailures.Add(
                                $"{job.Label}: requested Z{request.Zoom} not legal; " +
                                $"ArcGIS allows approximately Z{preflight.MostDetailedZoom}.");
                        }
                    }
                }
                finally
                {
                    if (!string.IsNullOrWhiteSpace(preflightMapName))
                        await QueuedTask.Run(() => DeletePrivateBatchMap(preflightMapName));
                }

                if (preflightFailures.Count > 0)
                {
                    SetStatus(
                        "BATCH NOT STARTED.\n\n" +
                        string.Join("\n", preflightFailures) +
                        "\n\nNo lower zoom was substituted.");
                    return;
                }

                var collisionErrors = CheckOutputCollisions(request);
                if (collisionErrors.Count > 0)
                {
                    SetStatus(
                        "BATCH NOT STARTED - OUTPUT FILE ALREADY EXISTS.\n\n" +
                        string.Join("\n", collisionErrors));
                    return;
                }

                var log = new StringBuilder();
                log.AppendLine("ARCGIS TPKX BATCH FACTORY - ISOLATED SEQUENTIAL");
                log.AppendLine($"Started: {DateTime.Now}");
                log.AppendLine($"Product: {request.ProductDisplay}");
                log.AppendLine($"Zoom: Z{request.Zoom}");
                log.AppendLine($"Destination: {request.Destination}");
                log.AppendLine($"Jobs: {request.Jobs.Count}");
                log.AppendLine();

                int passed = 0;
                int failed = 0;
                bool safetyStop = false;
                int expectedFilesPerJob = request.Product == ProductChoice.Both ? 2 : 1;

                for (int i = 0; i < request.Jobs.Count; i++)
                {
                    if (_cancelRequested || safetyStop)
                        break;

                    var job = request.Jobs[i];
                    JobText.Text = $"Job {i + 1} of {request.Jobs.Count} - {job.Label}";
                    CurrentActivityBar.Visibility = Visibility.Visible;

                    SetStatus(
                        $"JOB {i + 1} OF {request.Jobs.Count}\n\n" +
                        $"{job.Label}\n" +
                        $"{job.OriginalLine}\n\n" +
                        $"EXPORTING {request.ProductDisplay.ToUpperInvariant()} AT Z{request.Zoom}...");

                    var before = new HashSet<string>(
                        Directory.GetFiles(request.Destination, "*.tpkx"),
                        StringComparer.OrdinalIgnoreCase);

                    bool jobSucceeded = false;
                    string jobMessage;
                    string jobMapName = null;

                    try
                    {
                        // IMPORTANT: every row gets a brand-new private map.
                        // The map is never opened in a Pro pane and is deleted immediately
                        // after ExportRasterTileCache returns.  Therefore a package ArcGIS
                        // may attach to that map cannot ride into the next row.
                        var privateMap = await QueuedTask.Run(() => CreatePrivateBatchMap(request.Product, job.Label));
                        jobMapName = privateMap.Name;

                        await QueuedTask.Run(() =>
                        {
                            var extent = EnvelopeBuilderEx.CreateEnvelope(
                                job.XMin, job.YMin, job.XMax, job.YMax,
                                privateMap.Map.SpatialReference);

                            var exportParams = new ExportTileCacheParams
                            {
                                Extent = extent,
                                MaximumUserDefinedScale = job.ArcGISScale,
                                DestinationFolder = request.Destination
                            };

                            GenerateOfflineMap.Instance.ExportRasterTileCache(privateMap.Map, exportParams);
                        });

                        // Destroy the entire private map BEFORE touching the completed files.
                        // This releases any layer/package reference ArcGIS may have created.
                        await QueuedTask.Run(() => DeletePrivateBatchMap(jobMapName));
                        jobMapName = null;

                        var createdFiles = Directory.GetFiles(request.Destination, "*.tpkx")
                            .Where(p => !before.Contains(p))
                            .OrderBy(p => p)
                            .ToList();

                        if (createdFiles.Count != expectedFilesPerJob)
                        {
                            safetyStop = true;
                            throw new InvalidOperationException(
                                $"BATCH SAFETY STOP: Job {job.Label} created " +
                                $"{createdFiles.Count} TPKX file(s); expected {expectedFilesPerJob}. " +
                                "No additional batch jobs were started.");
                        }

                        var finalFiles = RenameCreatedFiles(
                            createdFiles, request.Product, job.Label, request.Destination);

                        jobSucceeded = true;
                        passed++;

                        jobMessage = string.Join(
                            "; ",
                            finalFiles.Select(path =>
                            {
                                var fi = new FileInfo(path);
                                return $"{fi.Name} ({fi.Length:N0} bytes)";
                            }));
                    }
                    catch (Exception ex)
                    {
                        failed++;
                        jobMessage = ex.GetType().Name + ": " + ex.Message;
                    }
                    finally
                    {
                        if (!string.IsNullOrWhiteSpace(jobMapName))
                        {
                            try
                            {
                                await QueuedTask.Run(() => DeletePrivateBatchMap(jobMapName));
                            }
                            catch
                            {
                                // Preserve the original job result. A stale private map is
                                // harmless to subsequent jobs because each job creates its own.
                            }
                        }
                    }

                    log.AppendLine(
                        $"{job.Label}: {(jobSucceeded ? "PASS" : "FAIL")} - {jobMessage}");
                    File.WriteAllText(logPath, log.ToString(), Encoding.UTF8);

                    OverallProgressBar.Value = i + 1;
                    CurrentActivityBar.Visibility = Visibility.Collapsed;

                    if ((i + 1) % 3 == 0 &&
                        i + 1 < request.Jobs.Count &&
                        !_cancelRequested &&
                        !safetyStop)
                    {
                        SetStatus(
                            $"SETTLING AFTER JOB {i + 1} OF {request.Jobs.Count}\n\n" +
                            "Waiting 120 seconds before starting the next group of jobs.");

                        log.AppendLine($"SETTLE: 120 seconds after {job.Label}.");
                        File.WriteAllText(logPath, log.ToString(), Encoding.UTF8);

                        await Task.Delay(TimeSpan.FromMinutes(2));
                    }
                }

                bool cancelled = _cancelRequested;
                int notRun = request.Jobs.Count - (passed + failed);

                log.AppendLine();
                log.AppendLine($"Finished: {DateTime.Now}");
                log.AppendLine($"Passed: {passed}");
                log.AppendLine($"Failed: {failed}");
                log.AppendLine($"Not run: {notRun}");
                log.AppendLine($"Cancelled: {cancelled}");
                log.AppendLine($"Safety stop: {safetyStop}");
                File.WriteAllText(logPath, log.ToString(), Encoding.UTF8);

                JobText.Text = cancelled
                    ? "Batch stopped."
                    : safetyStop
                        ? "Batch safety-stopped."
                        : "Batch complete.";

                SetStatus(
                    (cancelled
                        ? "BATCH STOPPED"
                        : safetyStop
                            ? "BATCH SAFETY STOPPED"
                            : "BATCH COMPLETE") + "\n\n" +
                    $"Passed: {passed}\n" +
                    $"Failed: {failed}\n" +
                    $"Not run: {notRun}\n\n" +
                    $"Log:\n{logPath}");
            }
            catch (Exception ex)
            {
                SetStatus(
                    "BATCH FAILED BEFORE/OUTSIDE A JOB\n\n" +
                    ex.GetType().Name + "\n" + ex.Message);
            }
            finally
            {
                CurrentActivityBar.Visibility = Visibility.Collapsed;
                SetBusy(false);
            }
        }

        private async Task<JobPreflight> PreflightJob(Map map, BatchJob job, int zoom)
        {
            return await QueuedTask.Run(() =>
            {
                var sr = map.SpatialReference;

                if (sr == null || sr.Wkid != 3857)
                    throw new InvalidOperationException(
                        $"Active map must use EPSG:3857. ArcGIS reports WKID {sr?.Wkid}.");

                var extent = EnvelopeBuilderEx.CreateEnvelope(
                    job.XMin, job.YMin, job.XMax, job.YMax, sr);

                var offline = GenerateOfflineMap.Instance;

                if (!offline.GetCanExportRasterTileCache(map))
                    throw new InvalidOperationException(
                        "ArcGIS reports no exportable raster tile cache in the active map.");

                var legalScales = offline.GetExportRasterTileCacheScales(map, extent);
                if (legalScales == null || legalScales.Count == 0)
                    throw new InvalidOperationException(
                        "ArcGIS returned no legal offline scales.");

                double desired = ZoomScales[zoom];
                double closest = legalScales
                    .OrderBy(s => Math.Abs(s - desired))
                    .First();

                double mostDetailed = legalScales.Min();

                return new JobPreflight
                {
                    Allowed = Math.Abs(closest - desired) <= 2.0,
                    ArcGISScale = closest,
                    MostDetailedZoom = FindNearestZoom(mostDetailed)
                };
            });
        }

        private static List<string> CheckOutputCollisions(BatchRequest request)
        {
            var errors = new List<string>();

            foreach (var job in request.Jobs)
            {
                foreach (var target in ExpectedTargetFiles(
                    request.Product, job.Label, request.Destination))
                {
                    if (File.Exists(target))
                        errors.Add(Path.GetFileName(target));
                }
            }

            return errors;
        }

        private static List<string> RenameCreatedFiles(
            List<string> created,
            ProductChoice product,
            string label,
            string destination)
        {
            var final = new List<string>();
            string safe = SafeLabel(label);

            foreach (var source in created)
            {
                string name = Path.GetFileName(source);
                string targetName;

                if (name.IndexOf(
                    "Reference_World_Transportation",
                    StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    targetName = $"Reference_World_Transportation Grid {safe}.tpkx";
                }
                else if (name.IndexOf(
                    "World_Imagery",
                    StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    targetName = $"World_Imagery Grid {safe}.tpkx";
                }
                else
                {
                    targetName = $"ArcGIS_TPKX Grid {safe} {final.Count + 1}.tpkx";
                }

                string target = Path.Combine(destination, targetName);

                if (File.Exists(target))
                    throw new IOException($"Output already exists: {targetName}");

                File.Move(source, target);
                final.Add(target);
            }

            return final;
        }

        private static IEnumerable<string> ExpectedTargetFiles(
            ProductChoice product,
            string label,
            string destination)
        {
            string safe = SafeLabel(label);

            if (product == ProductChoice.Road || product == ProductChoice.Both)
                yield return Path.Combine(
                    destination,
                    $"Reference_World_Transportation Grid {safe}.tpkx");

            if (product == ProductChoice.Satellite || product == ProductChoice.Both)
                yield return Path.Combine(
                    destination,
                    $"World_Imagery Grid {safe}.tpkx");
        }

        private static string SafeLabel(string label)
        {
            var bad = Path.GetInvalidFileNameChars();
            var chars = label
                .Select(c => bad.Contains(c) ? '_' : c)
                .ToArray();

            string safe = new string(chars).Trim();
            return string.IsNullOrWhiteSpace(safe) ? "MAP" : safe;
        }

        private static (Map Map, string Name) CreatePrivateBatchMap(
            ProductChoice product,
            string purpose)
        {
            string safePurpose = SafeLabel(purpose);
            string mapName = $"__TPKX_BATCH_{safePurpose}_{Guid.NewGuid():N}";

            var map = MapFactory.Instance.CreateMap(
                mapName,
                MapType.Map,
                MapViewingMode.Map,
                Basemap.None);

            map.SetSpatialReference(
                SpatialReferenceBuilder.CreateSpatialReference(3857));

            if (product == ProductChoice.Satellite ||
                product == ProductChoice.Both)
            {
                LayerFactory.Instance.CreateLayer(
                    new Uri(ImageryUrl, UriKind.Absolute),
                    map);
            }

            if (product == ProductChoice.Road ||
                product == ProductChoice.Both)
            {
                LayerFactory.Instance.CreateLayer(
                    new Uri(TransportationUrl, UriKind.Absolute),
                    map);
            }

            return (map, mapName);
        }

        private static void DeletePrivateBatchMap(string mapName)
        {
            if (string.IsNullOrWhiteSpace(mapName))
                return;

            IProjectItem item = Project.Current
                .GetItems<MapProjectItem>()
                .FirstOrDefault(m =>
                    m.Name.Equals(mapName, StringComparison.Ordinal));

            if (item != null)
                Project.Current.RemoveItem(item);
        }

        private bool TryReadBatch(out BatchRequest request, out string error)
        {
            request = null;
            error = "";

            var lines = _extentBoxes
                .Select(box => box.Text?.Trim() ?? "")
                .Where(text => !string.IsNullOrWhiteSpace(text))
                .ToList();

            if (lines.Count == 0)
            {
                error = "Load at least one extent.";
                return false;
            }

            var jobs = new List<BatchJob>();

            for (int i = 0; i < lines.Count; i++)
            {
                if (!TryParseExtent(lines[i], i + 1, out var job, out var parseError))
                {
                    error = $"Row {i + 1}: {parseError}";
                    return false;
                }

                jobs.Add(job);
            }

            int zoom = GetSelectedZoom();
            string destination = (DestinationTextBox.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(destination))
            {
                error = "Choose a destination folder.";
                return false;
            }

            try
            {
                Directory.CreateDirectory(destination);
            }
            catch (Exception ex)
            {
                error = "Destination cannot be created/opened.\n\n" + ex.Message;
                return false;
            }

            var product = RoadRadio.IsChecked == true
                ? ProductChoice.Road
                : SatelliteRadio.IsChecked == true
                    ? ProductChoice.Satellite
                    : ProductChoice.Both;

            request = new BatchRequest
            {
                Product = product,
                ProductDisplay = product switch
                {
                    ProductChoice.Satellite => "Satellite Imagery",
                    ProductChoice.Road => "Road Overlay",
                    _ => "Satellite + Road Overlay"
                },
                Zoom = zoom,
                Destination = destination,
                Jobs = jobs
            };

            return true;
        }

        private static bool TryParseExtent(
            string line,
            int row,
            out BatchJob job,
            out string error)
        {
            job = null;
            error = "";

            var match = ExtentRegex.Match(line);

            if (!match.Success)
            {
                error =
                    "Extent not recognized. Expected: " +
                    "3-01 xmin,xmax,ymin,ymax [EPSG:3857]";
                return false;
            }

            if (!double.TryParse(
                    match.Groups["xmin"].Value,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double xmin) ||
                !double.TryParse(
                    match.Groups["xmax"].Value,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double xmax) ||
                !double.TryParse(
                    match.Groups["ymin"].Value,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double ymin) ||
                !double.TryParse(
                    match.Groups["ymax"].Value,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double ymax))
            {
                error = "Coordinate parse failure.";
                return false;
            }

            if (xmin >= xmax || ymin >= ymax)
            {
                error = "Invalid X/Y ordering.";
                return false;
            }

            string label = match.Groups["label"].Success
                ? match.Groups["label"].Value
                : $"JOB{row:00}";

            job = new BatchJob
            {
                Label = label,
                OriginalLine = line,
                XMin = xmin,
                XMax = xmax,
                YMin = ymin,
                YMax = ymax
            };

            return true;
        }

        private int GetSelectedZoom()
        {
            if (ZoomComboBox.SelectedItem is ComboBoxItem item)
            {
                string text = item.Content?.ToString() ?? "";

                if (text.StartsWith("Z") &&
                    int.TryParse(text.Substring(1), out int z))
                    return z;
            }

            return 17;
        }

        private static int FindNearestZoom(double scale)
        {
            return ZoomScales
                .OrderBy(kvp => Math.Abs(kvp.Value - scale))
                .First()
                .Key;
        }

        private void SetBusy(bool busy)
        {
            BuildBatchButton.IsEnabled = !busy;
            CancelBatchButton.IsEnabled = busy;
            PasteMultipleButton.IsEnabled = !busy;
            ClearRowsButton.IsEnabled = !busy;
            BrowseButton.IsEnabled = !busy;
            DestinationTextBox.IsEnabled = !busy;
            ZoomComboBox.IsEnabled = !busy;
            SatelliteRadio.IsEnabled = !busy;
            RoadRadio.IsEnabled = !busy;
            BothRadio.IsEnabled = !busy;

            foreach (var box in _extentBoxes)
                box.IsEnabled = !busy;

            if (!busy)
                CancelBatchButton.IsEnabled = false;
        }

        private void SetStatus(string text)
        {
            StatusTextBox.Text = text;
            StatusTextBox.ScrollToEnd();
            BatchSummaryText.Text = text.Split('\n').FirstOrDefault() ?? text;
        }

        private enum ProductChoice
        {
            Satellite,
            Road,
            Both
        }

        private sealed class BatchRequest
        {
            public ProductChoice Product { get; set; }
            public string ProductDisplay { get; set; } = "";
            public int Zoom { get; set; }
            public string Destination { get; set; } = "";
            public List<BatchJob> Jobs { get; set; } = new();
        }

        private sealed class BatchJob
        {
            public string Label { get; set; } = "";
            public string OriginalLine { get; set; } = "";
            public double XMin { get; set; }
            public double XMax { get; set; }
            public double YMin { get; set; }
            public double YMax { get; set; }
            public double ArcGISScale { get; set; }
        }

        private sealed class JobPreflight
        {
            public bool Allowed { get; set; }
            public double ArcGISScale { get; set; }
            public int MostDetailedZoom { get; set; }
        }
    }
}
